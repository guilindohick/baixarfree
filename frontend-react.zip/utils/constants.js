export const base_url = process.env.BASE_URL;
export const domain = process.env.DOMAIN_URL;
