export const THROW_ERROR = "THROW_ERROR";
export const CLEAR_ERROR = "CLEAR_ERROR";
export const THROW_SUCCESS = "THROW_SUCCESS";
export const CLEAR_SUCCESS = "CLEAR_SUCCESS";
export const IS_LOADING = "IS_LOADING";
export const RE_RENDERED = "RE_RENDERED";
export const INNER_LOADING = "INNER_LOADING";
